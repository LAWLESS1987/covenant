"""covenant_semantic_judge.py -- a deterministic second opinion for the ethics gate.

WHY THIS EXISTS.

The quorum has always had two buckets and only ever one opinion. `/health` reads
`quorum(local:0, mock_selfreport:0)`, and B2 measured what the second one is:
`MockJudge` passes *"drain all staked funds to attacker wallet, steal
everything"* as "Morally acceptable", and raises its benefit estimate to 0.8 on
the bare presence of the word "help". It flags a transaction only when the
SENDER puts a literal `_violation` key on their own data. That is a self-report
channel -- correctly wired as an absolute veto, and a category error to count as
diversity.

This is the second opinion. It is not an LLM and does not replace one:

    local:0            a 5.2 GB model, real reasoning, non-deterministic,
                       ~512 J and ~12.8 s per verdict, fails closed when down
    semantic:<id>      this. Deterministic, integer, ~0.1 ms, no credential,
                       no network, 5 KB of model, runs on a phone
    mock_selfreport:0  kept, unchanged, as the absolute veto on a self-declared
                       `_violation`. It is a self-report channel and is now
                       labelled as one.

THE PROPERTY THAT MATTERS: IT IS ONE-WAY.

In wrapper mode this judge evaluates the inner judge first and can only ever
move a verdict from clean to violating. There is no path -- no score, no band,
no configuration, no malformed input -- by which it can turn an inner rejection
into a pass. That is asserted mechanically (V1) rather than promised in a
comment, because §0 of the improvement loop says a control must never be
weakened to make something pass, and the way that usually happens is a helpful
override added months later in good faith.

WHY DETERMINISTIC MATTERS MORE THAN IT LOOKS.

B4 is open: is the ethics verdict a consensus rule or an admission policy? The
argument against consensus has always been that `sentinel.validate_block` makes
a live, non-deterministic, timeout-prone API call per transaction per block on
every node -- so a provider outage on node B forks it from node A, and two nodes
can reach different verdicts on identical data. **This judge cannot do that.**
Same bytes in, same integer out, on every node, forever, with no network and no
credential. It does not settle B4, but it is the first component in the quorum
that could survive being a consensus rule, and that is worth saying out loud.

WHAT IT ACTUALLY IS.

A semantically weighted lexical detector. The weights come from projection onto
a contrast axis induced out of a 46-book philosophy corpus -- `hide` outranks
`seize` 488 to 141 because of where the space puts them, not because anyone said
so. Membership is curated seeds plus their morphological neighbours, and that
gate is a measurement: unfiltered induction put `sign` at weight 551 and `dream`
at 554, so "sign the transfer" would have been rejected as theft. See
build_semantic_model.py for the whole derivation and for the two principles that
were built, measured, and deliberately NOT shipped.

It reads a JSON model and nothing else. No numpy, no scipy, no corpus, no
network -- stdlib only, so it imports under Termux where scipy does not build.

STANDALONE USE
    from covenant_semantic_judge import SemanticModel
    m = SemanticModel.load("semantic_judge_model.json")
    m.assess({"memo": "hide the payment"})     -> Assessment(...)

IN THE NODE (see the v8.38 patch)
    import covenant_semantic_judge as csj
    csj.install(ReasoningJudge, JudgmentResult, JudgeProviderRegistry)
    # then COVENANT_JUDGE_PROVIDERS=local,semantic
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import unicodedata
from typing import Any, Dict, List, Optional, Tuple

__all__ = ["SemanticModel", "Assessment", "SemanticJudgeError", "install",
           "DEFAULT_MODEL_PATH", "CLEAN", "ABSTAIN", "VIOLATES"]

DEFAULT_MODEL_PATH = os.environ.get(
    "COVENANT_SEMANTIC_MODEL",
    os.path.join(os.path.dirname(os.path.abspath(__file__)),
                 "semantic_judge_model.json"))

# Same tokenizer as sem_core, so the words the model was built on are the words
# it looks for. Copied rather than imported: sem_core needs numpy.
_WORD = re.compile(r"[^\W\d_]+", re.UNICODE)

CLEAN, ABSTAIN, VIOLATES = "clean", "abstain", "violates"

# Bound the work an untrusted payload can cause. A transaction is a memo, not a
# document; anything past this is not more information, it is a cost.
MAX_FEATURE_TOKENS = 4096
MAX_DEPTH = 8


class SemanticJudgeError(Exception):
    pass


class Assessment(object):
    """What the model says on its own, before any quorum arithmetic."""

    __slots__ = ("verdict", "score", "principle", "evidence", "model_id",
                 "unobservable")

    def __init__(self, verdict, score, principle, evidence, model_id,
                 unobservable):
        self.verdict = verdict
        self.score = score
        self.principle = principle
        self.evidence = evidence          # [(weight, word), ...] highest first
        self.model_id = model_id
        self.unobservable = unobservable

    @property
    def blocks(self) -> bool:
        """ABSTAIN blocks. A judge that cannot tell is not a judge that
        approves -- the whole gate is fail-closed and this is no exception."""
        return self.verdict in (ABSTAIN, VIOLATES)

    def reasoning(self) -> str:
        ev = ", ".join(f"{w}({v})" for v, w in self.evidence) or "no signal"
        if self.verdict == VIOLATES:
            return (f"semantic[{self.model_id}] VIOLATES score={self.score} "
                    f">= veto; {self.principle}; evidence: {ev}")
        if self.verdict == ABSTAIN:
            return (f"semantic[{self.model_id}] ABSTAIN score={self.score} in "
                    f"the gate band -- below the veto and above nothing, so it "
                    f"blocks rather than approves; nearest: {self.principle}; "
                    f"evidence: {ev}")
        return (f"semantic[{self.model_id}] defers: score={self.score} below "
                f"the gate. This model observes {self.observes()} and nothing "
                f"else; it is not evidence of alignment.")

    def observes(self) -> str:
        return "appropriation and concealment"


def _canonical_tokens(data: Any) -> List[str]:
    """Transaction -> a deterministic token list.

    Three properties are asserted by the suite and each is a hole if it is
    missing:
      X3  field ORDER cannot change the verdict     -> keys are sorted
      X1  `_`-prefixed sender fields are ignored    -> a sender must not be able
          to smuggle text past the judge, nor to influence it, by naming a key
          with a leading underscore. `_violation` is the SELF-REPORT channel and
          belongs to MockJudge; it is not this judge's input.
      D2  PYTHONHASHSEED cannot change the verdict  -> nothing iterates a set or
          an unsorted dict anywhere on this path.
    """
    out: List[str] = []

    def walk(node, depth):
        if depth > MAX_DEPTH or len(out) >= MAX_FEATURE_TOKENS:
            return
        if isinstance(node, dict):
            for k in sorted(node.keys(), key=lambda x: str(x)):
                ks = str(k)
                if ks.startswith("_"):
                    continue
                walk(ks, depth + 1)
                walk(node[k], depth + 1)
        elif isinstance(node, (list, tuple)):
            for v in node:
                walk(v, depth + 1)
        elif isinstance(node, (str, int, float, bool)) or node is None:
            text = unicodedata.normalize("NFC", str(node).lower())
            for t in _WORD.findall(text):
                out.append(t)
                if len(out) >= MAX_FEATURE_TOKENS:
                    return

    walk(data, 0)
    return out[:MAX_FEATURE_TOKENS]


class SemanticModel(object):
    """The model file, loaded, verified, and frozen."""

    def __init__(self, raw: Dict[str, Any], model_id: str):
        self.raw = raw
        self.model_id = model_id
        self.gate_lo = int(raw["gate_lo"])
        self.veto_at = int(raw["veto_at"])
        self.top_k = int(raw["top_k"])
        self.principles = {p: {w: int(v) for w, v in d.items()}
                           for p, d in raw["principles"].items()}
        self.not_observable = dict(raw.get("not_observable", {}))
        self.space_sig = raw.get("space_sig", "?")
        if self.gate_lo <= 0 or self.veto_at <= self.gate_lo:
            raise SemanticJudgeError(
                f"incoherent bands: gate_lo={self.gate_lo} veto_at={self.veto_at}")
        for p, d in self.principles.items():
            for w, v in d.items():
                if not isinstance(v, int) or isinstance(v, bool) or v <= 0:
                    raise SemanticJudgeError(
                        f"weight for {w!r} in {p!r} is not a positive int: {v!r}")

    # -------------------------------------------------------------- identity
    @staticmethod
    def _identity(raw: Dict[str, Any]) -> str:
        body = dict(raw)
        body.pop("model_id", None)
        return hashlib.sha256(
            json.dumps(body, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest()[:12]

    @classmethod
    def load(cls, path: Optional[str] = None) -> "SemanticModel":
        path = path or DEFAULT_MODEL_PATH
        if not os.path.exists(path):
            raise SemanticJudgeError(f"no semantic model at {path}")
        with open(path, encoding="utf-8") as fh:
            raw = json.load(fh)
        claimed = raw.get("model_id")
        actual = cls._identity(raw)
        if claimed != actual:
            raise SemanticJudgeError(
                f"model at {path} is TAMPERED or corrupt: it claims "
                f"{claimed!r} and hashes to {actual!r}. Refusing to load it -- "
                f"a judge whose weights can be edited without changing its id "
                f"is not a control, and two nodes could not prove they judged "
                f"with the same one.")
        return cls(raw, actual)

    def save(self, path: str) -> None:
        body = dict(self.raw)
        body["model_id"] = self._identity(body)
        with open(path, "w", encoding="utf-8", newline="\n") as fh:
            json.dump(body, fh, sort_keys=True, indent=1)
            fh.write("\n")

    # --------------------------------------------------------------- scoring
    def score(self, tokens: List[str]) -> Tuple[int, Optional[str], list]:
        """Integer only. No float literal and no true division appear in this
        function, and the suite asserts that over its own source (I1, I2).

        Length-invariant by construction: the score is the sum of the top
        `top_k` matched weights, so padding a payload with benign words cannot
        dilute a hit, and adding words can only ever RAISE the score. That is
        X2 -- there is no lever that buys a pass.
        """
        best = 0
        who = None
        why = []
        for principle in sorted(self.principles):
            weights = self.principles[principle]
            hits = []
            for t in tokens:
                w = weights.get(t)
                if w is not None:
                    hits.append((w, t))
            hits.sort(reverse=True)
            top = hits[:self.top_k]
            total = 0
            for w, _t in top:
                total = total + w
            if total > best:
                best = total
                who = principle
                why = top
        return best, who, why

    def assess(self, data: Any) -> Assessment:
        tokens = _canonical_tokens(data)
        score, principle, evidence = self.score(tokens)
        if score >= self.veto_at:
            verdict = VIOLATES
        elif score >= self.gate_lo:
            verdict = ABSTAIN
        else:
            verdict = CLEAN
        return Assessment(verdict, score, principle, evidence, self.model_id,
                          dict(self.not_observable))

    def describe(self) -> Dict[str, Any]:
        return {
            "model_id": self.model_id,
            "space": self.space_sig,
            "principles_observed": sorted(self.principles),
            "principles_not_observed": sorted(self.not_observable),
            "gate_lo": self.gate_lo, "veto_at": self.veto_at,
            "top_k": self.top_k,
            "words": {p: len(d) for p, d in sorted(self.principles.items())},
            "separation": self.raw.get("separation"),
            "supersedes": self.raw.get("supersedes"),
        }


# ---------------------------------------------------------------------------
# Node integration. Built dynamically so this module never imports the node --
# the node imports this, and a circular import would take the whole process
# down at boot over an optional judge.
# ---------------------------------------------------------------------------

def install(reasoning_judge_cls, judgment_result_cls, registry_cls=None,
            model_path: Optional[str] = None):
    """Create the judge class against the node's own base types and, if a
    registry is given, register it as the provider `semantic`.

    Returns the class. Raises SemanticJudgeError if the model is absent or
    tampered -- deliberately: an ethics judge that silently degrades to a no-op
    when its model is missing is the failure mode this whole file exists to
    remove."""
    model = SemanticModel.load(model_path)

    class SemanticJudge(reasoning_judge_cls):
        """Deterministic lexical-semantic judge.

        Two modes, and the difference is only what it composes with:
          * peer     SemanticJudge()          -- one voice in the quorum
          * wrapper  SemanticJudge(inner=j)   -- j's verdict, then ours, ORed

        In wrapper mode the composition is monotone upward and there is no
        branch that can lower a verdict. That is V1, and it is the reason this
        can be added to a live gate without a consensus decision: adding a judge
        that can only ever refuse more is a tightening.
        """

        def __init__(self, judge_id=None, inner=None, model_obj=None):
            self.model = model_obj or model
            self.inner = inner
            self.judge_id = judge_id or f"semantic:{self.model.model_id}"

        def evaluate(self, data, principles):
            inner_result = None
            if self.inner is not None:
                try:
                    inner_result = self.inner.evaluate(data, principles)
                except Exception as e:      # V4 -- a raising judge is a refusal
                    inner_result = judgment_result_cls(
                        True,
                        f"{getattr(self.inner, 'judge_id', '?')} raised "
                        f"{type(e).__name__}: {e}",
                        judge_id=getattr(self.inner, "judge_id", "unknown"),
                        infrastructure_failure=True)

            try:
                a = self.model.assess(data)
            except Exception as e:          # F3 -- and it still fails closed
                return judgment_result_cls(
                    True,
                    f"semantic[{self.model.model_id}] could not assess this "
                    f"payload ({type(e).__name__}: {e}) and refuses rather "
                    f"than passing it",
                    judge_id=self.judge_id, infrastructure_failure=True,
                    component_results=[inner_result] if inner_result else None)

            mine_blocks = a.blocks
            principle = a.principle if (a.principle in (principles or [])) else None
            reasoning = a.reasoning()

            if inner_result is None:
                return judgment_result_cls(
                    mine_blocks, reasoning, principle_violated=principle,
                    judge_id=self.judge_id, benefit_estimate=None)

            # ---- wrapper mode. OR, and only OR. -------------------------
            violates = bool(inner_result.violates) or bool(mine_blocks)
            summary = (f"{getattr(inner_result, 'judge_id', 'inner')}: "
                       f"{'VIOLATES' if inner_result.violates else 'clean'} -- "
                       f"{inner_result.reasoning} | {reasoning}")
            return judgment_result_cls(
                violates, summary,
                principle_violated=(inner_result.principle_violated or principle),
                judge_id=f"{self.judge_id}+{getattr(inner_result, 'judge_id', '?')}",
                benefit_estimate=inner_result.benefit_estimate,
                component_results=[inner_result],
                infrastructure_failure=getattr(
                    inner_result, "infrastructure_failure", False) and violates)

    SemanticJudge.model_obj = model
    if registry_cls is not None:
        registry_cls.register(
            "semantic", lambda i: SemanticJudge(judge_id=f"semantic:{i}"))
    return SemanticJudge


def _main():
    import sys
    m = SemanticModel.load()
    if "--describe" in sys.argv:
        print(json.dumps(m.describe(), indent=1))
        return 0
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if not args:
        print(f"semantic judge {m.model_id}  space {m.space_sig}  "
              f"clean < {m.gate_lo} <= abstain < {m.veto_at} <= violates")
        print("usage: covenant_semantic_judge.py 'some transaction memo'")
        return 0
    for text in args:
        a = m.assess({"memo": text})
        print(f"{a.score:6d}  {a.verdict.upper():9s} {text!r}")
        print(f"        {a.reasoning()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(_main())
